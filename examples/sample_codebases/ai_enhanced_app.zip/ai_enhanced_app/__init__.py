"""
AI-Enhanced App Example
A sample application demonstrating AI agent usage for testing AutoGraph's agent detection capabilities.
""" 