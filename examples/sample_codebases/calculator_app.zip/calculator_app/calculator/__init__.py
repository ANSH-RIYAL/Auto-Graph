"""
Calculator package for the sample web app.
"""

__version__ = "1.0.0" 