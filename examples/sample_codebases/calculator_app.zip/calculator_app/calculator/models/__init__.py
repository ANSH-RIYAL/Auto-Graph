"""
Models package for the calculator app.
""" 