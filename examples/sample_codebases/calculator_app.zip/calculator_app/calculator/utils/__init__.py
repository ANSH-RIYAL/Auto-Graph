"""
Utilities package for the calculator app.
""" 