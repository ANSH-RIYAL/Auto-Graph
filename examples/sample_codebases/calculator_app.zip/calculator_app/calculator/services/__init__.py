"""
Services package for the calculator app.
""" 